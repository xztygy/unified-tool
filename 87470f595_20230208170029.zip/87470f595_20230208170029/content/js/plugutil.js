                (function (window, undefined) {
                    function init(paramsObj) {
                        var state = {
                            current: 1,
                            pageCount: 0,
                            size: 10
                        };
                        state.size = paramsObj.size
                        state.pagesize = paramsObj.pagesize;
                        state.total = paramsObj.total
                        paramsObj.pageCount = Math.ceil(paramsObj.total / paramsObj.size);
                        if (isNaN(paramsObj.pageCount)) {
                            throw new Error("total and pagesize must be a number ")
                        }
                        // 表格容器
                        state.tablecontan = paramsObj.tablecontan
                        // 表格数据
                        state.data = paramsObj.data
                        // 页面元素的外部容器
                        state.container = paramsObj.container || 'body'
                        // 总页数量参数
                        state.pageCount = paramsObj.pageCount
                        // 初始页参数
                        state.current = paramsObj.current
                        // 回调函数
                        state.onPageChange = paramsObj.onPageChange
                        // 当选中页码时添加的类名class
                        state.activeCName = paramsObj.activeCName || 'current_report'
                        // 代表页码数字的属性
                        state.dataNumberAttr = paramsObj.dataNumberAttr || 'tcdNumber'
                        // 上一页 按钮的类名class
                        state.prevCName = paramsObj.prevCName || 'prevPage'
                        // 下一页 按钮的类名class
                        state.nextCName = paramsObj.nextCName || 'nextPage'
                        // 渲染分页的dom对象
                        renderPageDOM(state)
                        // 加载input框输入分页跳转 加载
                    }

                    function switchPage(args) {

                        // 所有的页码元素a，包括上一页、下一页
                        var pCNameList = selectorEle(args.container + " a", true)
                        var current
                        for (i in pCNameList) {
                            if (i < pCNameList.length)
                                pCNameList[i].addEventListener("click", function () {
                                    if (this.className == args.activeCName) return
                                    var dataNumberAttr = this.innerHTML
                                    if (dataNumberAttr == "←" || dataNumberAttr == "→") {
                                        // current = parseInt(this.className.match(/\d/)[0])
                                    } else if (this.className == args.prevCName) {
                                        args.current > 1 && (current = args.current - 1)
                                    } else if (this.className == args.nextCName) {
                                        args.current < args.pageCount && (current = args.current + 1)
                                    } else {
                                        current = parseInt(dataNumberAttr)
                                    }
                                    current && gotoPage(current, args)
                                })
                        }
                        // input 输入去哪页
                        document.getElementById("pageinput" + args.pageConName).addEventListener("keydown", function (e) {
                            if (e.keyCode == 13 && (parseInt(this.value) | 0) === parseInt(this.value) && args
                                .pageCount >= parseInt(this.value) && parseInt(this.value) >= 1) {
                                args.current = parseInt(this.value)
                                init(args)
                                this.innerHTML = parseInt(this.value)
                                gotoPage(args.current, args);
                            }
                        })
                        // select 页码size分页
                        document.getElementById("z-select" + args.pageConName).addEventListener("change", function (e) {
                            args.size = parseInt(this.value)
                            args.current = 1;
                            // console.log("this.value1", g.state.size)
                            init(args)
                            this.value = args.size
                            console.log("this.value2", this.value)
                            gotoPage(args.current, args);
                        })
                    }

                    function renderPageDOM(args) {
                        // 重新计算页大小
                        var total = args.total;
                        var size = args.size;
                        var pageContainer = selectorEle(args.container)
                        if (total >= size) {
                            args.pageCount = Math.ceil(total / size);
                            // 获取容器ClassName
                            var pageConName = args.container
                            pageConName = pageConName.replace(new RegExp("\.", ""), "-")
                            // 添加到属性
                            args.pageConName = pageConName;
                            // console.log(pageConName)
                            var paginationStr = '',
                                start, end
                            var topagenum = args.current;
                            var temppagesize = args.pagesize || [10, 50, 100, 500, 1000, 5000, 10000];
                            var pagesize = [];
                            for (let i = 0; i < temppagesize.length; i++) {
                                const element = temppagesize[i];
                                if (total >= element) {
                                    pagesize.push(element);
                                }
                            }

                            if (!(Array.isArray(pagesize))) {
                                throw new Error("PageSize must be an array ")
                            }
                            if (!pagesize.every(e => (e | 0) === e)) {
                                throw new Error("PageSize in every particular must be a number ")
                            }
                            pagesize = pagesize.map((e) => {
                                // console.log("e:"+e+" size:" + size + " bool:" + (e == size))
                                if (e == size) {
                                    return `<option value ="${e}" selected>${e}条/页</option>`
                                }
                                return `<option value ="${e}">${e}条/页</option>`
                            }).join("")
                            if (args.current > 1) {
                                paginationStr = `<a href = "javascript:;"
                            class="prevPage">上一页</a><select id="z-select${pageConName}" name="cars"
                                value="${size}">${pagesize}</select>`;
                            } else {
                                paginationStr = `<a class="disabled">上一页</a><select id="z-select${pageConName}" name="cars"
                                value="${size}">${pagesize}</select>`;
                            }

                            if (args.pageCount < 6) {
                                // 总页数小于6的时候直接遍历。
                                for (start = 0; start < args.pageCount; start++) {
                                    end = start + 1;
                                    if (end == args.current) {
                                        paginationStr += '<a class="current_report">' + end + '</a>';
                                    } else {
                                        paginationStr += '<a href = "javascript:;" class="tcdNumber">' + end + '</a>';
                                    }
                                }
                            } else {
                                start = args.current - 1;
                                end = args.current + 1;
                                if (args.current > 2) {
                                    paginationStr += '<a href = "javascript:;" class="tcdNumber">' + 1 +
                                        '</a>';
                                } else if (args.pageCount > 4) {
                                    end = 4
                                };
                                if (args.current > args.pageCount - 3 && args.pageCount - 3 > 0) {
                                    start = args.pageCount - 3;
                                }
                                if (args.current > 3) {
                                    paginationStr += '<a href = "javascript:;" class="tcdNumber ' + (start - 1) +
                                        '" style="" οnmοuseοver="this.innerHTML=\'<\'" οnmοuseοut="this.innerHTML=\'...\'">...</a>';
                                }
                                // 中间页数利用循环生成
                                for (; start <= end; start++) {
                                    if (start <= args.pageCount && start > 0) {
                                        if (start == args.current) {
                                            paginationStr += '<a class="current_report">' + start + '</a>';
                                        } else {
                                            paginationStr += '<a href = "javascript:;" class="tcdNumber">' + start + '</a>';
                                        }
                                    }
                                }
                                // 判断临界值插入省略号
                                if (args.current < args.pageCount - 2) {
                                    paginationStr += '<a href = "javascript:;" class="tcdNumber ' + (end + 1) +
                                        '" style="width:" οnmοuseοver="this.innerHTML=\'>\'" οnmοuseοut="this.innerHTML=\'...\'">...</a>';
                                }
                                // 将中间数值插入html内容中
                                if (args.current < args.pageCount - 1) {
                                    paginationStr += '<a href="javascript:;" class="tcdNumber">' + args.pageCount + '</a>';
                                }
                            }
                            if (args.current < args.pageCount) {
                                paginationStr += `<input type="text" style="width:60px"  id="pageinput${pageConName}" value="${topagenum}" ><a href = "javascript:;" class="nextPage">下一页</a>`;
                            } else {
                                paginationStr += `<input type="text" style="width:60px"  id="pageinput${pageConName}" value="${topagenum}" ><a class="disabled">下一页</a>`;
                            }

                            pageContainer.innerHTML = paginationStr
                            switchPage(args)

                            var pageInput = document.getElementById("pageinput" + pageConName)
                            var pageZ_select = document.getElementById("z-select" + pageConName)

                            // console.log(pageNot);
                            // console.log(pageInput);
                            // console.log(pageZ_select);

                            if (pageContainer != null) {
                                pageContainer.style.display = 'table';
                                pageContainer.style.margin = '50px auto';
                                pageContainer.style.color = '#ccc';
                                pageContainer.style.WebkitTouchCallout = 'none';
                                pageContainer.style.WebkitUserSelect = 'none';
                                pageContainer.style.KhtmlUserSelect = 'none';
                                pageContainer.style.MozUserSelect = 'none';
                                pageContainer.style.msUserSelect = 'none';
                                pageContainer.style.userSelect = 'none';
                            }


                            if (pageInput != null) {
                                pageInput.style.cursor = "default";
                                pageInput.style.display = "inline-block";
                                pageInput.style.color = "#428bca";
                                pageInput.style.height = "25px";
                                pageInput.style.fontSize = "10pt";
                                pageInput.style.lineHeight = "25px";
                                pageInput.style.padding = "0 9px";
                                pageInput.style.border = "1px solid #ddd";
                                pageInput.style.margin = "0 2px";
                                pageInput.style.borderRadius = "4px";
                                pageInput.style.verticalAlign = "middle";
                                pageInput.style.width = "60px";
                            }
                            if (pageZ_select != null) {
                                pageZ_select.style.cursor = "default";
                                pageZ_select.style.display = "inline-block";
                                pageZ_select.style.color = "#428bca";
                                pageZ_select.style.height = "25px";
                                pageZ_select.style.fontSize = "10pt";
                                pageZ_select.style.lineHeight = "25px";
                                pageZ_select.style.padding = "0 9px";
                                pageZ_select.style.border = "1px solid #ddd";
                                pageZ_select.style.margin = "0 2px";
                                pageZ_select.style.borderRadius = "4px";
                                pageZ_select.style.verticalAlign = "middle";
                                pageZ_select.style.width = "auto";
                            }

                            var pCNameList = selectorEle(args.container + " a", true)
                            for (i in pCNameList) {
                                if (i < pCNameList.length) {
                                    var classNameList = pCNameList[i].className
                                    if (classNameList != 'disabled' && classNameList != 'current_report') {
                                        //console.log(classNameList);
                                        pCNameList[i].style.cursor = "default";
                                        pCNameList[i].style.display = "inline-block";
                                        pCNameList[i].style.color = "#428bca";
                                        pCNameList[i].style.height = "25px";
                                        pCNameList[i].style.fontSize = "10pt";
                                        pCNameList[i].style.lineHeight = "25px";
                                        pCNameList[i].style.padding = "0 9px";
                                        pCNameList[i].style.border = "1px solid #ddd";
                                        pCNameList[i].style.margin = "0 2px";
                                        pCNameList[i].style.borderRadius = "4px";
                                        pCNameList[i].style.verticalAlign = "middle";
                                        pCNameList[i].style.width = "auto";

                                        pCNameList[i].addEventListener("mouseenter", function () {
                                            //设置其背景颜色为黄色
                                            this.style.border = '1px solid #428bca';
                                            this.style.cursor = 'pointer';
                                        })
                                        pCNameList[i].addEventListener("mouseleave", function () {
                                            //设置其背景颜色为黄色
                                            this.style.border = "1px solid #ddd";
                                            this.style.cursor = "default";
                                        })
                                    }
                                    if (classNameList == 'disabled') {
                                        pCNameList[i].style.display = "inline-block";
                                        pCNameList[i].style.fontSize = "10pt";
                                        pCNameList[i].style.height = "25px";
                                        pCNameList[i].style.lineHeight = "25px";
                                        pCNameList[i].style.padding = "0 9px";
                                        pCNameList[i].style.margin = "0 2px";
                                        pCNameList[i].style.color = "#bfbfbf";
                                        pCNameList[i].style.background = "#f2f2f2";
                                        pCNameList[i].style.border = "1px solid #bfbfbf";
                                        pCNameList[i].style.borderRadius = "4px";
                                        pCNameList[i].style.verticalAlign = "middle";
                                        pCNameList[i].style.cursor = "no-drop";
                                    }
                                    if (classNameList == 'current_report') {
                                        pCNameList[i].style.display = "inline-block";
                                        pCNameList[i].style.fontSize = "10pt";
                                        pCNameList[i].style.height = "25px";
                                        pCNameList[i].style.lineHeight = "25px";
                                        pCNameList[i].style.padding = "0 9px";
                                        pCNameList[i].style.margin = "0 2px";
                                        pCNameList[i].style.color = "#fff";
                                        pCNameList[i].style.backgroundColor = "#428bca";
                                        pCNameList[i].style.border = "1px solid #428bca";
                                        pCNameList[i].style.borderRadius = "4px";
                                        pCNameList[i].style.verticalAlign = "middle";
                                    }
                                }
                            }
                        } else {
                            pageContainer.innerHTML = '';
                        }
                        renderTable(args.current, size, args.data, args.tablecontan, total)
                        console.log(args.tablecontan + ": 内容加载完成")
                        ImagePreview();
                    }
                    // 渲染函数
                    function renderTable(page, size, date, tabel, total) {
                        // 页面描述
                        var finalVal = size * page <= total ? size * page : total;
                        var theUL = selectorEle(tabel);
                        theUL.innerHTML = '';
                        var pageContent = '';
                        for (var i = (page - 1) * size; i < finalVal; i++) {
                            pageContent += date[i]
                        }
                        theUL.innerHTML = pageContent;
                    }

                    function gotoPage(current, args) {
                        args.current = current
                        renderPageDOM(args);
                        args.onPageChange(args.current)
                    }

                    function hasClass(eleObj, className) {
                        return eleObj.classList.contains(className);
                    }

                    function inputpage(val) {

                    }

                    function selectorEle(selector, all) {
                        return all ? document.querySelectorAll(selector) : document.querySelector(selector)
                    }
                    //添加到全局环境
                    PageUtil = {
                        init: init
                    }
                    ImagePreview();
                    window.onresize =function(){
                        RefreshLineChart()
                    }
                })(window)




                function highLight(input, content) {
                    if (content.length > 0) {
                        var input_key = input;
                        // 如果用户名中包含，关键字就替换一下
                        if (content.match(new RegExp(input_key, 'ig'))) {
                            // 获取起始位置
                            var punctuation = content.toUpperCase().indexOf(input_key.toUpperCase());
                            var MaTheValue = '';
                            //  获取匹配到的值
                            if (punctuation != -1) {
                                MaTheValue = content.substring(punctuation, punctuation + input_key.length);
                            }
                            // 打印迷彩部分
                            content = content.replace(
                                new RegExp(input_key, 'ig'),
                                // 这里是替换成html格式的数据，最好再加一个样式权重，保险一点
                                '<b style="color:green">' + MaTheValue + '</b>'
                            );
                        }
                    }
                    return content
                }

                function scrollToView(traget) {
                    const tragetElem = document.getElementById(traget);
                    const tragetElemPostition = tragetElem.offsetTop;

                    // 判断是否支持新特性
                    if (
                        typeof window.getComputedStyle(document.body).scrollBehavior ==
                        "undefined"
                    ) {
                        // 当前滚动高度
                        let scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
                        // 滚动step方法
                        const step = function () {
                            // 距离目标滚动距离
                            let distance = tragetElemPostition - scrollTop;

                            // 目标需要滚动的距离
                            scrollTop = scrollTop + (distance / 5);
                            if (Math.abs(distance) < 1) {
                                window.scrollTo(0, tragetElemPostition);
                            } else {
                                window.scrollTo(0, scrollTop);
                                setTimeout(step, 17);
                            }
                        };
                        step();
                    } else {
                        tragetElem.scrollIntoView({
                            behavior: "smooth",
                            inline: "nearest"
                        });
                    }
                }


                /**
                 * 使用match方法实现模糊查询
                 * @param  {Array}  list     进行查询的数组
                 * @param  {String} keyWord  查询的关键词
                 * @return {Array}           查询的结果
                 */
                function fuzzyQueryUserMsg(list, keyWord) {
                    var pageData = [];
                    if (keyWord != "") {
                        for (var i = 0; i < list.length; i++) {
                            if (list[i].msgtype == "text") {
                                if (list[i].content.match(new RegExp(keyWord, 'ig'))) {
                                    var data = '<tr>' +
                                        '<td>' + list[i].sendTime + '</td>' +
                                        '<td>' +
                                        '<pre class="self_adaption2">' +
                                        highLight(keyWord, list[i].content) +
                                        '</pre>' +
                                        '</td>' +
                                        '<td>' + list[i].sender + '</td>' +
                                        '<td>' + list[i].recipient + '</td>' +
                                        '<td>' + list[i].acquisition + '</td>' +
                                        '</tr>';
                                    pageData.push(data);
                                }
                            }
                        }
                        if (pageData.length === 0) {
                            var data = '<tr>' +
                                '<td colspan="5" style="text-align: center;">' +
                                '<span>没有找到相关数据！试试其他词语吧。</span>'
                            '</td>'
                            '</tr>';
                            pageData.push(data);
                        }
                    } else {
                        for (var i = 0; i < list.length; i++) {
                            var content = list[i].content;
                            if (list[i].msgtype == "text") {
                                content = '<pre class="self_adaption2">' + list[i].content + '</pre>'
                            }
                            var data = '<tr>' +
                                '<td>' + list[i].sendTime + '</td>' +
                                '<td>' + content + '</td>' +
                                '<td>' + list[i].sender + '</td>' +
                                '<td>' + list[i].recipient + '</td>' +
                                '<td>' + list[i].acquisition + '</td>' +
                                '</tr>';
                            pageData.push(data);
                        }
                    }
                    return pageData;
                }

                //表格滑过
                function MouseMovementEffect(tabelId) {

                    var table = document.querySelector(tabelId);
                    var rows = table.getElementsByTagName("tr");
                    for (var i = 0; i < rows.length; i++) {
                        var row = rows[i];
                        row.onmouseover = function () {
                            this.style.backgroundColor = "#F5F7FA";
                            // this.style.fontSize = "20px";
                        };
                        row.onmouseout = function () {
                            this.style.backgroundColor = "";
                            this.style.fontSize = "";
                        }
                    }
                }


                // 图像预览
                function ImagePreview() {

                    // Create a new div element
                    var black_overlay = document.createElement('div');
                    var enlargeContainer = document.createElement('div');
                    var closeBtn = document.createElement('button');
                    var lastdiv = document.createElement('div');


                    var closeSvg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
                    // Create a <polygon> element and set its attributes.
                    var polygon = document.createElementNS("http://www.w3.org/2000/svg", "path");
                    polygon.setAttribute("d", "M764.288 214.592 512 466.88 259.712 214.592a31.936 31.936 0 0 0-45.12 45.12L466.752 512 214.528 764.224a31.936 31.936 0 1 0 45.12 45.184L512 557.184l252.288 252.288a31.936 31.936 0 0 0 45.12-45.12L557.12 512.064l252.288-252.352a31.936 31.936 0 1 0-45.12-45.184z");
                    polygon.setAttribute("fill", "white");
                    closeSvg.setAttribute("viewBox", "0 0 1024 1024");
                    closeSvg.setAttribute("xmlns", "http://www.w3.org/2000/svg");
                    closeSvg.style.transform = 'translate(0%,5%)';
                    closeSvg.style.width = "22px";
                    closeSvg.style.height = "22px";

                    // Add the <polygon> element to the SVG.
                    closeSvg.appendChild(polygon);

                    black_overlay.setAttribute("class", "black_overlay");

                    // Set the div's styles
                    black_overlay.style.top = '0';
                    black_overlay.style.bottom = '0';
                    black_overlay.style.left = '0';
                    black_overlay.style.right = '0';
                    black_overlay.style.width = '100%';
                    black_overlay.style.height = '100%';
                    black_overlay.style.backgroundColor = 'rgba(34, 34, 34, 0.7)';
                    black_overlay.style.display = 'none';
                    black_overlay.style.position = 'fixed';
                    black_overlay.style.zIndex = '100';

                    enlargeContainer.style.display = 'none';

                    closeBtn.style.position = 'fixed';
                    closeBtn.style.top = '20px';
                    closeBtn.style.right = '20px';
                    closeBtn.style.width = '44px';
                    closeBtn.style.height = '44px';
                    closeBtn.style.cursor = 'pointer';
                    closeBtn.style.zIndex = '200';
                    closeBtn.style.border = 0;
                    closeBtn.style.backgroundColor = 'rgba(26, 26, 26, 0.7)';
                    closeBtn.style.borderRadius = '50%';
                    closeBtn.style.backgroundPosition = 'center';
                    closeBtn.style.fontSize = '20px';

                    lastdiv.style.width = '100%';
                    lastdiv.style.height = '100%';
                    lastdiv.style.position = 'fixed';


                    closeBtn.innerHTML = closeSvg.outerHTML;

                    enlargeContainer.appendChild(lastdiv);
                    enlargeContainer.appendChild(closeBtn);
                    black_overlay.appendChild(enlargeContainer);

                    var paragraphs = document.querySelectorAll('.black_overlay');
                    if (paragraphs.length > 0) {
                        paragraphs[0].parentNode.replaceChild(black_overlay, paragraphs[0]);
                    } else {
                        if (document.body != null) {
                            document.body.appendChild(black_overlay);
                        }
                    }

                    var bodyImages = document.querySelectorAll('.main_c img');
                    var bodyvideo = document.querySelectorAll('.main_c video');

                    bodyImages.forEach(function (toEnlargeImg) {
                        toEnlargeImg.addEventListener('click', function () {
                            document.body.style.overflow = 'hidden';
                            // 获取当前图片的路径
                            let imgUrl = this.src;
                            // 显示黑色遮罩和预览容器
                            black_overlay.style.display = 'block';
                            enlargeContainer.style.display = 'block';
                            let img = new Image();
                            img.src = imgUrl;
                            img.style.position = 'fixed';
                            img.style.top = '50%';
                            img.style.left = '50%';
                            img.style.maxWidth = '70%';
                            img.style.maxHeight = '90%';
                            img.style.zIndex = '200';
                            img.style.transform = 'translate(-50%,-50%)';

                            if (closeBtn.nextElementSibling) {
                                enlargeContainer.removeChild(closeBtn.nextElementSibling);
                            }
                            enlargeContainer.appendChild(img);

                        });
                    });

                    bodyvideo.forEach(function (toEnlargeVideo) {
                        toEnlargeVideo.addEventListener('click', function () {
                            document.body.style.overflow = 'hidden';
                            // 显示黑色遮罩和预览容器
                            black_overlay.style.display = 'block';
                            enlargeContainer.style.display = 'block';
                            var video = document.createElement('VIDEO');
                            var source = document.createElement('source');
                            video.setAttribute("controls", "controls");
                            video.style.position = 'fixed';
                            video.style.top = '50%';
                            video.style.left = '50%';
                            video.style.maxWidth = '70%';
                            video.style.height = '100%';
                            video.style.zIndex = '200';
                            video.style.transform = 'translate(-50%,-50%)';
                            source.src = this.currentSrc;
                            source.setAttribute("type", "video/mp4");

                            if (closeBtn.nextElementSibling) {
                                enlargeContainer.removeChild(closeBtn.nextElementSibling);
                            }
                            video.appendChild(source);
                            enlargeContainer.appendChild(video);
                        });
                    });



                    // 关闭预览
                    closeBtn.addEventListener('click', function () {
                        black_overlay.style.display = 'none';
                        enlargeContainer.style.display = 'none';
                        document.body.style.overflow = 'visible';
                    });
                    lastdiv.addEventListener('click', function () {
                        black_overlay.style.display = 'none';
                        enlargeContainer.style.display = 'none';
                        document.body.style.overflow = 'visible';
                    });
                }

            // 创建折线图
                function createMonthLineChart(container,month,count) {
                    var chartX = document.createElement('div')
                    chartX.setAttribute("class", "chartX")

                    // 总数
                    var result = 0
                    var result_max = 0

                    for (let i = count.length -1; i >= 0; i--) {
                        if (i < 10) {
                            result_max = Math.max(result_max, count[i])
                            result += parseInt(count[i])
                        }
                    }

                    for (let i = month.length - 1; i >= 0; i--) {
                        if (i < 10) {
                            const el_month = month[i]
                            const el_count = parseInt(count[i])
                            // 数量/总数*100%
                            var percentage = (el_count / result_max * 100).toFixed(0)

                            if (percentage < 1) {
                                if (el_count > 0) {
                                    percentage = 1
                                }
                            }

                            var dot = document.createElement('div')
                            dot.setAttribute("class", "dot")
                            var result_bar = document.createElement('div')
                            result_bar.setAttribute("class", "result-bar")
                            result_bar.setAttribute("data-count", el_count)
                            result_bar.style.height = percentage + "%"
                            result_bar.appendChild(dot)

                            var result_bg = document.createElement('div')
                            result_bg.setAttribute("class", "result-bg")
                            result_bg.setAttribute("data-month", el_month)
                            result_bg.appendChild(result_bar)

                            chartX.appendChild(result_bg)
                        }

                    }

                    var str = result_max
                    var cahr = result_max
                    var temp = (cahr * 0.2).toFixed(0);
                    for (let i = 0; i < 5; i++) {
                        cahr = cahr - temp; 
                        if (i < 4) {
                            str += "\n" + cahr
                        } else {
                            str += "\n" + 0
                        }
                    }
                    chartX.setAttribute("data-beforeData", str)
                    container.appendChild(chartX)
                    RefreshLineChart()
                }

                function RefreshLineChart(){
                    const bars = document.querySelectorAll('.result-bar .dot')
                    bars.forEach((bar, index) => {
                        const nextBar = bars[index + 1]
                        if (!nextBar) {
                            return
                        }
                        let elLine = bar.querySelector('i')
                        if (!elLine) {
                            elLine = document.createElement('i')
                            elLine.setAttribute('line', '')
                            bar.appendChild(elLine)
                        }
                        // 计算线段长度和旋转弧度
                        let boundThis = bar.getBoundingClientRect(),
                            boundNext = nextBar.getBoundingClientRect(),
                            x1 = boundThis.left,
                            y1 = boundThis.top,
                            x2 = boundNext.left,
                            y2 = boundNext.top,
                            distance = Math.sqrt(Math.pow((x1 - x2), 2) + Math.pow((y1 - y2), 2)),
                            radius = Math.atan((y2 - y1) / (x2 - x1))
                        // console.log(distance, radius)
                        // 计算线段长度
                        elLine.style.width = `${distance}px`
                        // 旋转弧度
                        elLine.style.transform = `rotate(${radius}rad)`
                    })
                }




                function createFollowTable(){


                // 创建头像仓位
                var img = document.createElement('img')
                img.setAttribute("src","")
                img.setAttribute("class","avatar")
                img.setAttribute("alt","")
                var td_avatar = document.createElement('td')
                td_avatar.setAttribute("class","avatar_td")
                td_avatar.appendChild(img)
                // 创建对象信息仓位
                var id = document.createElement('span')
                var username = document.createElement('span')
                var phonenum = document.createElement('span')
                var updateAt = document.createElement('span')
                var desc = document.createElement('span')

                id.innerText = "ID:"
                username.innerText = "用户名："
                phonenum.innerText = "手机号："
                updateAt.innerText = "更新时间："
                desc.innerText = "描述："

                var object_info_tr0_td0 = document.createElement('td')
                var object_info_tr0_td1 = document.createElement('td')
                var object_info_tr0_td2 = document.createElement('td')

                var object_info_tr1_td0 = document.createElement('td')

                var object_info_tr2_td0 = document.createElement('td')

                object_info_tr2_td0.setAttribute("colspan","3")
                object_info_tr2_td0.setAttribute("class","self_adaption")


                object_info_tr0_td0.appendChild(id)
                object_info_tr0_td1.appendChild(username)
                object_info_tr0_td2.appendChild(phonenum)

                object_info_tr1_td0.appendChild(updateAt)

                object_info_tr2_td0.appendChild(desc)

                object_info_tr0_td0.innerText = ""
                object_info_tr0_td1.innerText = ""
                object_info_tr0_td2.innerText = ""
                object_info_tr1_td0.innerText = ""


                var object_info_tr0 = document.createElement('tr')
                var object_info_tr1 = document.createElement('tr')
                var object_info_tr2 = document.createElement('tr')

                object_info_tr0.appendChild(object_info_tr0_td0)
                object_info_tr0.appendChild(object_info_tr0_td1)
                object_info_tr0.appendChild(object_info_tr0_td2)

                object_info_tr1.appendChild(object_info_tr1_td0)

                object_info_tr2.appendChild(object_info_tr2_td0)


                var object_info_tbody = document.createElement('tbody')
                var caption = document.createElement('caption')
                // 昵称
                caption.innerText=""
                var object_info_table = document.createElement('table')
                object_info_table.setAttribute("class","table_2")
                object_info_table.setAttribute("border","0")
                object_info_table.setAttribute("cellpadding","0")
                object_info_table.setAttribute("cellspacing","0")
                object_info_table.appendChild(caption)
                object_info_table.appendChild(object_info_tbody)
                object_info_table.appendChild(object_info_tr0)
                object_info_table.appendChild(object_info_tr1)
                object_info_table.appendChild(object_info_tr2)
                var td = document.createElement('td')

                var tr = document.createElement('tr')
                tr.appendChild(td_avatar)
                tr.appendChild(td)

                var tbody = document.createElement('tbody')
                tbody.appendChild(tr)

                  var table = document.createElement('table')
                  table.setAttribute("class","table_3")
                  table.setAttribute("border","0")
                  table.setAttribute("cellpadding","0")
                  table.setAttribute("cellspacing","0")

                  table.appendChild(tbody)


                }

